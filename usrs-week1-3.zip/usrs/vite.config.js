import { defineConfig } from 'vite';

// Relative base so the built site works from a GitHub Pages project URL
// (https://<user>.github.io/<repo>/) as well as from Netlify or Vercel.
export default defineConfig({
  base: './',
  server: {
    port: 5173,
    open: true,
  },
  build: {
    outDir: 'dist',
  },
});
